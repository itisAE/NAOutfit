'''
TOR: Versione ottimizzata utilizzando mediapipe, preso spunto dal codice trovato qui: https://github.com/AnanthaKannan/ai-media-pipe
per la documentazione guardare questo link: https://medium.com/@sreeananthakannan/full-body-tracking-c7c4cf68bb9d 
aggiunte le funzioni 
#?calculateLung(lmList, bodyPartNum1, bodyPartNum2):
prende in input l'array di array delle coordinate  di ogni punto(**float), il punto di partenza(int) e il punto di arrivo (int)
#?mediaValori(misurazioniArto) 
prende in input l'array di misurazioni(*float) e restituisce la media dei valori(float)


PER PROVARE IL PROGRAMMA:
assicurarsi di avere tutte le librerie installate (per mediapipe se si ha Linux come SO verificare la possibilità di tirare su un venv (https://docs.python.org/3/library/venv.html))
eseguire da terminale python3 mediapipeV2_TOR_rilevaCorpo.py

POSIZIONAMENTO FOTOCAMERA
230cm dal soggetto
500cm --> distanza in cui le misurazioni coincidono coi cm

Diverso coefficiente per cui dividere spalle/braccia e gambe causa proporzioni

POSIZIONE FOTOCAMERA PC AD UN ALTEZZA DI 1 METRO CIRCA PER LE GIUSTE PROPORZIONI

'''


import cv2
import mediapipe as mp
import time
import math
import cv2 as cv
import numpy as np
from scipy.stats import iqr
from taglieLib import *
import argparse


class poseDetector():
    def __init__(self, mode=False, smooth=True, detectionCon=0.5, trackCon=0.5):
        self.mode = mode
        self.smooth = smooth
        self.detectionCon = detectionCon
        self.trackCon = trackCon
        self.pTime = 0

        self.mpDraw = mp.solutions.drawing_utils
        self.mpPose = mp.solutions.pose
        self.pose = self.mpPose.Pose(static_image_mode=self.mode,
                                smooth_landmarks=self.smooth,
                                min_detection_confidence=self.detectionCon,
                                min_tracking_confidence=self.trackCon)

    def findPose(self, img, draw=True):
        imgRGB = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        self.results = self.pose.process(imgRGB)

        if self.results.pose_landmarks:
            if draw:
                self.mpDraw.draw_landmarks(img, self.results.pose_landmarks, self.mpPose.POSE_CONNECTIONS)
        return img

    def getPosition(self, img):
        self.lmList = []
        if self.results.pose_landmarks:
            for id, lm in enumerate(self.results.pose_landmarks.landmark):
                h, w, c = img.shape
                cx, cy = int(lm.x * w), int(lm.y * h)
                self.lmList.append([id, cx, cy])
        return self.lmList

    def showFps(self, img):
        cTime = time.time()
        #print(cTime, self.pTime)
        fbs = 1 / (cTime - self.pTime)
        self.pTime = cTime
        cv2.putText(img, str(int(fbs)), (70, 80), cv2.FONT_HERSHEY_PLAIN, 3,
                    (255, 0, 0), 3)

    def findAngle(self, img, p1, p2, p3, draw=True):
        # Get the landmark
        x1, y1 = self.lmList[p1][1:]
        x2, y2 = self.lmList[p2][1:]
        x3, y3 = self.lmList[p3][1:]

        # Calculate the angle
        angle = math.degrees(math.atan2(y3 - y2, x3 - x2) - math.atan2(y1 - y2, x1 - x2))
        # some time this angle comes zero, so below conditon we added
        if angle < 0:
            angle += 360

        # Draw
        if draw:
            cv2.line(img, (x1, y1), (x2, y2), (255, 255, 255), 3)
            cv2.line(img, (x3, y3), (x2, y2), (255, 255, 255), 3)
            cv2.circle(img, (x1, y1), 10, (0, 0, 255), cv2.FILLED)
            cv2.circle(img, (x1, y1), 15, (0, 0, 255), 1)
            cv2.circle(img, (x2, y2), 10, (0, 0, 255), cv2.FILLED)
            cv2.circle(img, (x2, y2), 15, (0, 0, 255), 1)
            cv2.circle(img, (x3, y3), 10, (0, 0, 255), cv2.FILLED)
            cv2.circle(img, (x3, y3), 15, (0, 0, 255), 1)
            # cv2.putText(img, str(int(angle)), (x2 - 20, y2 + 50), cv2.FONT_HERSHEY_SIMPLEX,
            #             1, (0, 0, 255), 2)
        return angle

def calculateLung(lmList, bodyPartNum1, bodyPartNum2):
    xArt1 = lmList[bodyPartNum1][1]
    yArt1 = lmList[bodyPartNum1][2]
    xArt2 = lmList[bodyPartNum2][1]
    yArt2 = lmList[bodyPartNum2][2]
    lung = math.sqrt((xArt1 - xArt2)**2 + (yArt1 - yArt2)**2)
    return lung

def mediaValori(misurazioniArto):#accetta in input l'array del dizionario (es: dictArrDistance["braccia"])

    #TOR PARTE DI CALCOLO DEI DATI
    moltiplicatore = 2
    misurazioni = np.array(misurazioniArto)
    q1 = np.percentile(misurazioni, 25) #calcolo il primo quartile (valore sottoi lquale si trova il 25% dei dati)
    q3 = np.percentile(misurazioni, 75) #calcolo il terzo quartile 

    iqr_value = iqr(misurazioni) #calcolo il valore dell'interquartile

    soglia_inf = q1 - moltiplicatore * iqr_value #imposto soglia maggiore e soglia inferiore per gli outlier
    soglia_sup = q3 + moltiplicatore * iqr_value

    #li filtro
    misurazioni_filtrate = misurazioni[(misurazioni >= soglia_inf) & (misurazioni <= soglia_sup)]

    return np.mean(misurazioni_filtrate) #faccio la media tra tutti i valori dell'array

dictDistance = {
    "spalle" : 0,
    "braccia" : 0,
    "gambe" : 0,
    "vita" : 0
}

#dizionario con insieme di misure da calcolare
dictArrDistance = {
    "spalle" : [],
    "braccia" : [],
    "gambe" : [],
    "vita" : []
}

####################################################################################
#CONFIGURAZIONE TAGLIE
min_h_S = 0
max_h_S = 0
min_h_M = 0
max_h_M = 0
min_h_L = 0
max_h_L = 0
min_h_XL =0
max_h_XL = 0
#####################################################################################
dividendo_misurazioni = 2.1  #73913043 #coefficiente per cui dividere per la proporzione in cm

dividendo_gambe=1.35

# parser = argparse.ArgumentParser()
# parser.add_argument('vestito', default='maglia', help='Stringa del vestito selezionato')
# parser.add_argument('sesso', default='M', choices=['M', 'F'], help='Sesso (M o F)')
# parser.add_argument('--tagliaSuccessiva', action='store_true', help='True se vuoi taglia successiva, False altrimenti')

# args = parser.parse_args()
# arg1 = args.vestito
# arg2 = args.sesso
# arg3 = args.tagliaSuccessiva


def calcolaTaglia(arg1, arg2, arg3):
    print("Mettiti in posizione")
    time.sleep(3)
    detector = poseDetector()
    cap = cv2.VideoCapture(0)
    #cap = cv2.VideoCapture(6)
    start_time = time.time()
    durata_programma = 10
    #while True: #--originale
    while (cv.waitKey(1) < 0)and(time.time() - start_time < durata_programma):
        success, img = cap.read()
        img = detector.findPose(img)
        lmList = detector.getPosition(img)
        if  len(lmList):
           dictArrDistance["spalle"].append(calculateLung(lmList, 11, 12)/dividendo_misurazioni)
           temp = calculateLung(lmList, 11, 13)/dividendo_misurazioni
           dictArrDistance["braccia"].append((temp+calculateLung(lmList, 11, 15))/dividendo_misurazioni) #braccio destro
           temp = calculateLung(lmList, 12, 14)/dividendo_misurazioni
           dictArrDistance["braccia"].append((temp+calculateLung(lmList, 14, 16))/dividendo_misurazioni)#braccio sinistro
           temp = calculateLung(lmList, 24, 26)/dividendo_misurazioni
           dictArrDistance["gambe"].append((temp+ calculateLung(lmList, 26,28))/dividendo_gambe)#gamba sinistra
           temp = calculateLung(lmList, 23, 25)/dividendo_misurazioni
           dictArrDistance["gambe"].append((temp+ calculateLung(lmList, 25,27))/dividendo_gambe) #gamba destra
           dictArrDistance["vita"].append((temp+ calculateLung(lmList,24,23))/dividendo_misurazioni) #vita 
           #print(str(dictArrDistance["spalle"])+ "\n")
        #else:
            #print('lmList = '+str(lmList))
        detector.showFps(img)
        cv2.imshow("Image", img)
        cv2.waitKey(1)

    cap.release()
    cv2.destroyAllWindows()
    if not dictArrDistance["spalle"]:
        fp = open("result.txt", "w")
        fp.write(str(dictDistance))
    elif not dictArrDistance["gambe"]:
        fp = open("result.txt", "w")
        fp.write(str(dictDistance))
    elif not dictArrDistance["braccia"]:
        fp = open("result.txt", "w")
        fp.write(str(dictDistance))
    else:
        dictDistance["spalle"] = mediaValori(dictArrDistance["spalle"])
        #print("rilevazioni gambe"+str(dictArrDistance["gambe"]))
        dictDistance["gambe"] = mediaValori(dictArrDistance["gambe"])
        dictDistance["braccia"] = mediaValori(dictArrDistance["braccia"])
        dictDistance["vita"] = mediaValori(dictArrDistance["vita"])
        #print(dictDistance)
    
   


    if (arg1 == 'maglia'):
        spalle = dictDistance["spalle"] * 2.7
        lungBraccio = dictDistance["braccia"]
        tagliaSpalle = convertiTaglie(spalle, arg1, arg2, arg3)
        print("circonferenza spalle"+str(spalle))
        
        return tagliaSpalle

    elif (arg1 == 'pantaloni'):
        vita = dictDistance["vita"] * 2.2
        lungGambe = dictDistance["gambe"]
        tagliaGambe = convertiTaglie(vita, arg1, arg2, arg3)
        print("circonferenza vita"+str(vita))
        return tagliaGambe
    
    

#giro petto = 93
#vita = 82
#bacino  = 106


# if __name__ == "__main__":
#     main()

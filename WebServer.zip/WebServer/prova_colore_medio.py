import cv2
import numpy as np

""" apre il collegamento con la fotocamera scatta una foto che salva nella cartella foto, crea un'altra foto
con area 'area_centrale' e crea un foto con il colore medio"""

def scatta_foto(percorso_immagine = './prova.jpg'):#foto/
    # Apri la connessione con la telecamera (0 indica la telecamera predefinita)(2 fotocamera esterna test)
    cap = cv2.VideoCapture(0)
    #cap = cv2.VideoCapture(2)

    # Verifica se la telecamera è stata aperta correttamente
    if cap.isOpened() == False:
        print("Impossibile aprire la telecamera.")
        return

    # Cattura un singolo frame dalla telecamera
    corretto, frame = cap.read()

    # Controlla se il frame è stato catturato correttamente
    if not corretto:
        print("Impossibile catturare il frame.")
        return

    cv2.imwrite(percorso_immagine, frame)

    # Chiudi la telecamera
    cap.release()

    return frame

def ottieni_colore_medio(frame, percorso_immagine_area = './prova_area.jpg'):#foto/

    # Ottieni le dimensioni dell'immagine
    altezza, larghezza = frame.shape[:2]

    dimensione_area = 20

    # Calcola le coordinate dell'area centrale
    centro_x = larghezza // 2
    centro_y = altezza // 2

    # Ottieni l'area centrale dell'immagine
    area_centrale = frame[centro_y - dimensione_area:centro_y + dimensione_area, centro_x - dimensione_area:centro_x + dimensione_area]

    cv2.imwrite(percorso_immagine_area, area_centrale)

    # Calcola il colore medio dell'area centrale
    colore_medio = np.mean(area_centrale, axis=(0, 1))

    # Converte il valore del colore da BGR a RGB
    colore_medio_rgb = (int(colore_medio[2]), int(colore_medio[1]), int(colore_medio[0]))

    dimensioni = (65, 65)

    #crea l'immagine con dimensione dimensioni, gli fornisco i tre canali RGB e specifico che ogni elemento sarà un intero a 8 bit
    colore_immagine = np.zeros((dimensioni[0], dimensioni[1], 3), dtype=np.uint8)
    #assegna all'immagine il colore BGR
    colore_immagine[:, :] = colore_medio

    cv2.imwrite('./prova_colore.jpg', colore_immagine)#foto/

    # Stampa le informazioni
    print(f"Colore medio dell'area centrale: {colore_medio_rgb}")

# Chiama la funzione per scattare una foto e ottenere il colore medio dell'area centrale
frame = scatta_foto()
ottieni_colore_medio(frame)
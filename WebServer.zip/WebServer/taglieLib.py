#se tagliaSuccessiva è True allora il programma restituirà la misura successiva a quella attuale
def convertiTaglie(dato, vestito, sesso, tagliaSuccessiva):
    if sesso=='M':
        if vestito=='maglia':
            #rispetto al giro petto
            if dato>86 and dato<92:
                if(tagliaSuccessiva):
                    return 'M'
                return 'S'
            elif dato>=92 and dato<98:
                if(tagliaSuccessiva):
                    return 'L'
                return 'M'
            elif dato>=98 and dato<104:
                if(tagliaSuccessiva):
                    return 'XL'
                return 'L'
            elif dato>=104 and dato<114:
                if(tagliaSuccessiva):
                    return '2XL'
                return 'XL'
            elif dato>=114 and dato<124:
                if(tagliaSuccessiva):
                    return '3XL'
                return '2XL'
            elif dato>=124 and dato<134:
                if(tagliaSuccessiva):
                    return 'Err'
                return '3XL'
            else:
                return 'Err'  #errore
        elif vestito=='pantaloni':
            if dato>88 and dato<92:
                if(tagliaSuccessiva):
                    return ["IT 44", "EU 40"]
                return ["IT 42", "EU 38"]
            elif dato>=92 and dato<96:
                if(tagliaSuccessiva):
                    return ["IT 46", "EU 42"]
                return ["IT 44", "EU 40"]
            elif dato>=96 and dato<100:
                if(tagliaSuccessiva):
                    return ["IT 48", "EU 44"]
                return ["IT 46", "EU 42"]
            elif dato>=100 and dato<105:
                if(tagliaSuccessiva):
                    return ["IT 50", "EU 46"]
                return ["IT 48", "EU 44"]
            elif dato>=105 and dato<109:
                if(tagliaSuccessiva):
                    return ["IT 52", "EU 48"]
                return ["IT 50", "EU 46"]
            elif dato>=109 and dato<114:
                if(tagliaSuccessiva):
                    return ["IT 54", "EU 50"]
                return ["IT 52", "EU 48"]
            elif dato>=114 and dato<119:
                if(tagliaSuccessiva):
                    return ["IT 56", "EU 52"]
                return ["IT 54", "EU 50"]
            elif dato>=119 and dato<124:
                if(tagliaSuccessiva):
                    return ["IT 58", "EU 54"]
                return ["IT 56", "EU 52"]
            elif dato>=124 and dato<129:
                if(tagliaSuccessiva):
                    return 'Err'
                return ["IT 58", "EU 54"]
            else:
                return 'Err'  #errore
    elif sesso=='F':
        if vestito=='maglia':
            #rispetto a giro vita
            if dato>68 and dato<71:
                if(tagliaSuccessiva):
                    return 'S'
                return 'XS'
            elif dato>=71 and dato<74:
                if(tagliaSuccessiva):
                    return 'M'
                return 'S'
            elif dato>=74 and dato<77:
                if(tagliaSuccessiva):
                    return 'L'
                return 'M'
            elif dato>=77 and dato<89:
                if(tagliaSuccessiva):
                    return 'XL'
                return 'L'
            elif dato>=89 and dato<101:
                if(tagliaSuccessiva):
                    return '2XL'
                return 'XL'
            elif dato>=101 and dato<113:
                if(tagliaSuccessiva):
                    return '3XL'
                return '2XL'
            elif dato>=113 and dato<125:
                if(tagliaSuccessiva):
                    return 'Err'
                return '3XL'
            else:
                return 'Err'  #errore
        elif vestito=='pantaloni':
            if dato>58 and dato<62:
                if(tagliaSuccessiva):
                    return 'XS'
                return '2XS'
            elif dato>=62 and dato<65:
                if(tagliaSuccessiva):
                    return 'S'
                return 'XS'
            elif dato>=65 and dato<69:
                if(tagliaSuccessiva):
                    return 'M'
                return 'S'
            elif dato>=69 and dato<73:
                if(tagliaSuccessiva):
                    return 'L'
                return 'M'
            elif dato>=73 and dato<77:
                if(tagliaSuccessiva):
                    return 'L'
                return 'M/L'
            elif dato>=77 and dato<84:
                if(tagliaSuccessiva):
                    return 'XL'
                return 'L'
            elif dato>=84 and dato<90:
                if(tagliaSuccessiva):
                    return 'XL'
                return 'L/XL'
            elif dato>=90 and dato<96:
                if(tagliaSuccessiva):
                    return '2XL'
                return 'XL'
            elif dato>=96 and dato<102:
                if(tagliaSuccessiva):
                    return '2XL'
                return 'XL/2XL'
            elif dato>=102 and dato<108:
                if(tagliaSuccessiva):
                    return '3XL'
                return '2XL'
            elif dato>=108 and dato<114:
                if(tagliaSuccessiva):
                    return '3XL'
                return '2XL/3XL'
            elif dato>=114 and dato<120:
                if(tagliaSuccessiva):
                    return '4XL'
                return '3XL'
            elif dato>=120 and dato<128:
                if(tagliaSuccessiva):
                    return '4XL'
                return '3XL/4XL'
            elif dato>=128 and dato<132:
                if(tagliaSuccessiva):
                    return '5XL'
                return '4XL'
            elif dato>=132 and dato<139:
                if(tagliaSuccessiva):
                    return '5XL'
                return '4XL/5XL'
            elif dato>=139 and dato<145:
                if(tagliaSuccessiva):
                    return 'Err'
                return '5XL'
            else:
                return 'Err'  #errore
    else:
        return 'Err parametri'
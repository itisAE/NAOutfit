import webbrowser
import random

# def utente_generico(*args, **kwargs):
#     # Logica generica o default per l'utente
#     return f"Funzione generica per utente con argomenti {args} e keyword arguments {kwargs}"

# Creazione della tabella di mapping
#MMS =  maschi mori sci
#FBR =  femmine bionde running
#FMN = femmine more nuoto

pagine_da_aprire_MMS = ['http://www.google.com', 'https://chat.openai.com/', 'https://www.torellistudio.com/studio/']
pagine_da_aprire_MMR = ['http://www.google.com', 'https://chat.openai.com/', 'https://www.torellistudio.com/studio/']
pagine_da_aprire_MMN = ['http://www.google.com', 'https://chat.openai.com/', 'https://www.torellistudio.com/studio/']

pagine_da_aprire_MBS = ['http://www.google.com', 'http://www.google.com', 'http://www.google.com']
pagine_da_aprire_MBR = ['http://www.google.com', 'http://www.google.com', 'http://www.google.com']
pagine_da_aprire_MBN = ['http://www.google.com', 'http://www.google.com', 'http://www.google.com']

pagine_da_aprire_FMS = ['http://www.google.com', 'http://www.google.com', 'http://www.google.com']
pagine_da_aprire_FMR = ['http://www.google.com', 'http://www.google.com', 'http://www.google.com']
pagine_da_aprire_FMN = ['http://www.google.com', 'http://www.google.com', 'http://www.google.com']

pagine_da_aprire_FBS = ['http://www.google.com', 'http://www.google.com', 'http://www.google.com']
pagine_da_aprire_FBR = ['http://www.google.com', 'http://www.google.com', 'http://www.google.com']
pagine_da_aprire_FBN = ['http://www.google.com', 'http://www.google.com', 'http://www.google.com']

#sport: sci, running, nuoto

sport = ['sci', 'running', 'nuoto']

combinazioni_funzioni = {
    ('M', sport[0], 'moro'): lambda: webbrowser.open_new_tab(random.choice(pagine_da_aprire_MMS)),
    ('M', sport[1], 'moro'): lambda: webbrowser.open_new_tab(random.choice(pagine_da_aprire_MMR)),
    ('M', sport[2], 'moro'): lambda: webbrowser.open_new_tab(random.choice(pagine_da_aprire_MMN)),

    ('M', sport[0], 'biondo'): lambda: webbrowser.open_new_tab(random.choice(pagine_da_aprire_MBS)),
    ('M', sport[1], 'biondo'): lambda: webbrowser.open_new_tab(random.choice(pagine_da_aprire_MBR)),
    ('M', sport[2], 'biondo'): lambda: webbrowser.open_new_tab(random.choice(pagine_da_aprire_MBN)),

    ('F', sport[0], 'moro'): lambda: webbrowser.open_new_tab(random.choice(pagine_da_aprire_MMS)),
    ('F', sport[1], 'moro'): lambda: webbrowser.open_new_tab(random.choice(pagine_da_aprire_MMR)),
    ('F', sport[2], 'moro'): lambda: webbrowser.open_new_tab(random.choice(pagine_da_aprire_MMN)),
    
    ('F', sport[0], 'biondo'): lambda: webbrowser.open_new_tab(random.choice(pagine_da_aprire_MBS)),
    ('F', sport[1], 'biondo'): lambda: webbrowser.open_new_tab(random.choice(pagine_da_aprire_MBR)),
    ('F', sport[2], 'biondo'): lambda: webbrowser.open_new_tab(random.choice(pagine_da_aprire_MBN))
}




def gestisci_utente(sesso, sport, colore_capelli):
    # Cerca la funzione corrispondente nella tabella di mapping
    funzione = combinazioni_funzioni.get((sesso, sport, colore_capelli))
    
    # Chiamala e restituisci il risultato
    return funzione()

# Esempio di chiamata alla funzione
risultato = gestisci_utente('M', 'sci', 'moro')
print(risultato)
